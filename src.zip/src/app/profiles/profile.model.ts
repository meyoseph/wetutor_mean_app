export interface Profile {
  firstname: string;
  lastname: string;
  gender: string;
  age: number;
  educationlevel: string;
  mainsubject: string;
  language: string;
  image: string;
  cv: string;
  status: string;
}
