export interface AuthData{
  email: string;
  password: string;
  phonenumber: string;
  userType: string;
}
